from subjectHandling import *
from oneEuroFilter import *
import itertools

# Full test
TARGETS = range(8)
ENVIRONMENTS = ['U', 'W']
POSTURES = ['W','S']
BLOCKS = range(5)


for subjectNum in range(3, 4):
    fileLists = get_one_subject(subjectNum)
    # for target,env,pos,block in itertools.product(TARGETS,ENVIRONMENTS,POSTURES,BLOCKS):

    # just for test
    for target, env, pos, block in itertools.product(range(4,5), ['U', 'W'], ['W'], range(1)):
        trial_info = [target, env, pos, block]
        [ProcessingData, HololensData, filename] = get_each_file(fileLists[0], fileLists[1], subjectNum, trial_info)
        filtering(ProcessingData[0])
        # lookup_file(ProcessingData, HololensData, filename)

    print('-' * 80)
